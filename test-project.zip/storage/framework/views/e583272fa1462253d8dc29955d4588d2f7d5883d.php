<?php if (isset($component)) { $__componentOriginal9bff5d0fc55c103b0cdbcc582053f74ab4f0d63d = $component; } ?>
<?php $component = App\View\Components\MainLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('main-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\MainLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
	 <?php $__env->slot('title', null, []); ?> User profile <?php $__env->endSlot(); ?>
	 <?php $__env->slot('description', null, []); ?> This is the user profile page <?php $__env->endSlot(); ?>
	 <?php $__env->slot('robots', null, []); ?> index, follow <?php $__env->endSlot(); ?>
	 <?php $__env->slot('center', null, []); ?> 
		<div class="main">
<div id="notification"></div>

<div class="breadcrumb" itemscope="" itemtype="http://schema.org/BreadcrumbList">
<div class="breadcrumb__wrapper">
<div class="breadcrumb__row">
<span itemprop="itemListElement" itemscope="" itemtype="http://schema.org/ListItem">
<a class="breadcrumb__link" itemprop="item" href="https://it-rating.com/">
<span itemprop="name"><em class="fa fa-home"></em></span>
</a>
<meta itemprop="position" content="1">
</span>
<span itemprop="itemListElement" itemscope="" itemtype="http://schema.org/ListItem">
<a class="breadcrumb__link" itemprop="item" href="https://it-rating.com/my-account/">
<span itemprop="name">Account</span>
</a>
<meta itemprop="position" content="1">
</span>
<span class="breadcrumb__link breadcrumb__link_current">User profile</span>
</div>
</div>
</div>

<div class="main__page-wrap" style='margin-bottom:100px'>
<div class="columns">
<div class="content">
<div class="authorization authorization_login">
<h1 class="authorization__heading">Your profile</h1>
<div class="authorization__row">
<div class="authorization__left">

<div class="field formBlcok__field formBlcok__field_col12">
<div class="field__name">Name:</div>
<div class="field__inp">
<input type="text" name="email" placeholder="" value="<?php echo e(auth()->user()->name); ?>">
</div>
</div>
<div class="field formBlcok__field formBlcok__field_col12">
<div class="field__name">E-Mail:</div>
<div class="field__inp">
<input type="text" name="email" placeholder="" value="<?php echo e(auth()->user()->email); ?>">
</div>
</div>
<div class="field formBlcok__field formBlcok__field_col12">
<div class="field__name">Avatar:</div>
<div class="field__inp">
<img src="<?php echo e(auth()->user()->avatar); ?>" style='width: 85px'>
</div>
</div>

</div>
<div class="authorization__right">
<div class="authorization__info">

<div class="authorization__headingLight"><br></div><div class="authorization__txt"></div> </div>
</div>
</div>
</div>

</div>

</div>
</div>



</div>
	 <?php $__env->endSlot(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9bff5d0fc55c103b0cdbcc582053f74ab4f0d63d)): ?>
<?php $component = $__componentOriginal9bff5d0fc55c103b0cdbcc582053f74ab4f0d63d; ?>
<?php unset($__componentOriginal9bff5d0fc55c103b0cdbcc582053f74ab4f0d63d); ?>
<?php endif; ?><?php /**PATH C:\WebServer\domains\test-project\resources\views/dashboard.blade.php ENDPATH**/ ?>